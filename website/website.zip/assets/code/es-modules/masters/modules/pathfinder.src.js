/**
 * @license Highcharts Gantt JS v8.0.0 (2019-12-10)
 * @module highcharts/modules/pathfinder
 * @requires highcharts
 *
 * Pathfinder
 *
 * (c) 2016-2019 Øystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../parts-gantt/Pathfinder.js';
