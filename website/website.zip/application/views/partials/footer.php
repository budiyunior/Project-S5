<div class="footer">
    <div>
        <strong>Copyright</strong> If Technocraft &copy; 2019
    </div>
</div>